let menu_item = document.getElementsByTagName(li);
    li = document.createElement('li');

console.log(li);

 //menu_item[]


body.style.background = 'url(../img/apple_true.jpg)';